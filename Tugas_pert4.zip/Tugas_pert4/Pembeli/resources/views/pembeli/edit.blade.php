@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Edit Data</div>

                <div class="card-body">
                    <form method="POST" action="{{ route('pembeli.update',$pembeli['id']) }}">
                        @csrf
                        @method('PUT')

                        <div class="form-group row">
                            <label for="no_transaksi" class="col-md-4 col-form-label text-md-right">No Transaksi</label>

                            <div class="col-md-6">
                                <input id="no_transaksi" type="text" class="form-control{{ $errors->has('no_transaksi') ? ' is-invalid' : '' }}" name="no_transaksi" value="{{ old('no_transaksi') }}" required>

                                @if ($errors->has('no_transaksi'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('no_transaksi') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="nama" class="col-md-4 col-form-label text-md-right">Nama Pembeli</label>

                            <div class="col-md-6">
                                <input id="nama_pembeli" type="text" class="form-control{{ $errors->has('nama_pembeli') ? ' is-invalid' : '' }}" name="nama_pembeli" value="{{ old('nama_pembeli') }}" required autofocus>

                                @if ($errors->has('nama_pembeli'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('nama_pembeli') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="merk" class="col-md-4 col-form-label text-md-right">Merk</label>

                            <div class="col-md-6">
                                <input id="merk" value="{{$pembeli['merk']}}" type="text" class="form-control{{ $errors->has('merk') ? ' is-invalid' : '' }}" name="merk" value="{{ old('merk') }}" required>

                                @if ($errors->has('merk'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('merk') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        
                        <div class="form-group row">
                            <label for="jumlah_barang" class="col-md-4 col-form-label text-md-right">Jumlah Barang</label>

                            <div class="col-md-6">
                                <input id="jumlah_barang" value="{{$pembeli['jumlah_barang']}}" type="text" class="form-control{{ $errors->has('jumlah_barang') ? ' is-invalid' : '' }}" name="jumlah_barang" value="{{ old('jumlah_barang') }}" required>

                                @if ($errors->has('jumlah_barang'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('isi_silinder') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        
                        <div class="form-group row">
                            <label for="harga" class="col-md-4 col-form-label text-md-right">Harga</label>

                            <div class="col-md-6">
                                <input id="harga" value="{{$pembeli['harga']}}" type="text" class="form-control{{ $errors->has('harga') ? ' is-invalid' : '' }}" name="harga" value="{{ old('harga') }}" required>

                                @if ($errors->has('harga'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('harga') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

            
                         <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    {{ __('Edit') }}
                                </button>
                                <a href="{{ route('pembeli.index') }}" class="btn btn-danger">Back</a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection