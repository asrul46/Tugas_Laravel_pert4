@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">List Data Pembeli</div>
                <div> <a href="{{route('pembeli.create') }}" class="btn btn-danger">ADD LIST </a></div>

                <div class="card-body">
                        <table class="table table-striped">
                        <tr>
                            <th>No</th>
                            <th>No Transaksi</th>
                            <th>Nama Pembeli</th>
                            <th>Merk</th>
                            <th>Jumlah Barang</th>
                            <th>Harga</th>
                            <th>Aksi</th>

                        </tr>
                        <?php  $no=1; ?>
                        @foreach ($pembeli as $item)
                        <tr>
                            <td>{{$no}}</td>
                            <td>{{$item->no_transaksi}}</td>
                            <td>{{$item->nama_pembeli}}</td>
                            <td>{{$item->merk}}</td>
                            <td>{{$item->jumlah_barang}}</td>
                            <td>{{$item->harga}}</td> 
                            <td>
                                <a href="{{ route('pembeli.edit',$item->id) }}" class="btn btn-info btn-sm">EDIT </a>
                                <form method="POST" action="{{ route('pembeli.destroy',$item->id) }}">
                                @csrf
                                @method('DELETE')
                                
                                <button type="submit" class="btn btn-danger btn-sm">DELETE </button>
                                </form>

                            </td>
                        </tr>
                        <?php $no++; ?>
                        @endforeach

                      
                        </table>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
