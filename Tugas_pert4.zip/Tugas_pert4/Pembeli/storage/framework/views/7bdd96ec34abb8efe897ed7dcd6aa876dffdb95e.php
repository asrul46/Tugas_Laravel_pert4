<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">ADD DATA GUDANG SEMBAKO</div>

                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('gudang.store')); ?>">
                        <?php echo csrf_field(); ?>

                        <div class="form-group row">
                            <label for="nama" class="col-md-4 col-form-label text-md-right">Nama Barang</label>

                            <div class="col-md-6">
                                <input id="nama_barang" type="text" class="form-control<?php echo e($errors->has('nama_barang') ? ' is-invalid' : ''); ?>" name="nama_barang" value="<?php echo e(old('nama_barang')); ?>" required autofocus>

                                <?php if($errors->has('nama_barang')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('nama_barang')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="merk" class="col-md-4 col-form-label text-md-right">Merk</label>

                            <div class="col-md-6">
                                <input id="merk" type="text" class="form-control<?php echo e($errors->has('merk') ? ' is-invalid' : ''); ?>" name="merk" value="<?php echo e(old('merk')); ?>" required>

                                <?php if($errors->has('merk')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('merk')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="jumlah_barang" class="col-md-4 col-form-label text-md-right"><?php echo e(__('jumlah_barang')); ?></label>
                             <div class="col-md-6">
                                <input id="jumlah_barang" type="text" class="form-control<?php echo e($errors->has('jumlah_barang') ? ' is-invalid' : ''); ?>" name="jumlah_barang" required>

                                <?php if($errors->has('jumlah_barang')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('jumlah_barang')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="supplier" class="col-md-4 col-form-label text-md-right">Supplier</label>

                            <div class="col-md-6">
                                <input id="supplier" type="text" class="form-control<?php echo e($errors->has('supplier') ? ' is-invalid' : ''); ?>" name="supplier" value="<?php echo e(old('supplier')); ?>" required>

                                <?php if($errors->has('supplier')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('supplier')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="harga" class="col-md-4 col-form-label text-md-right">Harga</label>

                            <div class="col-md-6">
                                <input id="harga" type="text" class="form-control<?php echo e($errors->has('harga') ? ' is-invalid' : ''); ?>" name="harga" value="<?php echo e(old('harga')); ?>" required>

                                <?php if($errors->has('harga')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('harga')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                         <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    <?php echo e(__('ADD')); ?>

                                </button>
                                <a href="<?php echo e(route('gudang.index')); ?>" class="btn btn-danger">Back</a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\gudang\resources\views/gudang/create.blade.php ENDPATH**/ ?>