<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">List Data Pembeli</div>
                <div> <a href="<?php echo e(route('pembeli.create')); ?>" class="btn btn-danger">ADD LIST </a></div>

                <div class="card-body">
                        <table class="table table-striped">
                        <tr>
                            <th>No</th>
                            <th>No Transaksi</th>
                            <th>Nama Pembeli</th>
                            <th>Merk</th>
                            <th>Jumlah Barang</th>
                            <th>Harga</th>
                            <th>Aksi</th>

                        </tr>
                        <?php  $no=1; ?>
                        <?php $__currentLoopData = $pembeli; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($no); ?></td>
                            <td><?php echo e($item->no_transaksi); ?></td>
                            <td><?php echo e($item->nama_pembeli); ?></td>
                            <td><?php echo e($item->merk); ?></td>
                            <td><?php echo e($item->jumlah_barang); ?></td>
                            <td><?php echo e($item->harga); ?></td> 
                            <td>
                                <a href="<?php echo e(route('pembeli.edit',$item->id)); ?>" class="btn btn-info btn-sm">EDIT </a>
                                <form method="POST" action="<?php echo e(route('pembeli.destroy',$item->id)); ?>">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                
                                <button type="submit" class="btn btn-danger btn-sm">DELETE </button>
                                </form>

                            </td>
                        </tr>
                        <?php $no++; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                      
                        </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Semester6\Pembeli\resources\views/pembeli/index.blade.php ENDPATH**/ ?>