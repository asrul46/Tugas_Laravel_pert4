<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">ADD NEW MOTORS LIST</div>

                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('motors.store')); ?>">
                        <?php echo csrf_field(); ?>

                        <div class="form-group row">
                            <label for="nama" class="col-md-4 col-form-label text-md-right">Nama</label>

                            <div class="col-md-6">
                                <input id="nama" type="text" class="form-control<?php echo e($errors->has('nama') ? ' is-invalid' : ''); ?>" name="nama" value="<?php echo e(old('nama')); ?>" required autofocus>

                                <?php if($errors->has('nama')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('nama')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="merk" class="col-md-4 col-form-label text-md-right">Merk</label>

                            <div class="col-md-6">
                                <input id="merk" type="text" class="form-control<?php echo e($errors->has('merk') ? ' is-invalid' : ''); ?>" name="merk" value="<?php echo e(old('merk')); ?>" required>

                                <?php if($errors->has('merk')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('merk')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="isi_silinder" class="col-md-4 col-form-label text-md-right"><?php echo e(__('isi silinder')); ?></label>
                             <div class="col-md-6">
                                <input id="isi_silinder" type="text" class="form-control<?php echo e($errors->has('isi_silinder') ? ' is-invalid' : ''); ?>" name="isi_silinder" required>

                                <?php if($errors->has('isi_silinder')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('isi silinder')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="tahun_buat" class="col-md-4 col-form-label text-md-right">Tahun Pembuatan</label>

                            <div class="col-md-6">
                                <input id="tahun_buat" type="text" class="form-control<?php echo e($errors->has('tahun_buat') ? ' is-invalid' : ''); ?>" name="tahun_buat" value="<?php echo e(old('tahun_buat')); ?>" required>

                                <?php if($errors->has('tahun_buat')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('tahun buat')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="harga" class="col-md-4 col-form-label text-md-right">Harga</label>

                            <div class="col-md-6">
                                <input id="harga" type="text" class="form-control<?php echo e($errors->has('harga') ? ' is-invalid' : ''); ?>" name="harga" value="<?php echo e(old('harga')); ?>" required>

                                <?php if($errors->has('harga')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('harga')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                         <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    <?php echo e(__('ADD')); ?>

                                </button>
                                <a href="<?php echo e(route('motors.index')); ?>" class="btn btn-danger">Back</a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\motor\resources\views/motors/create.blade.php ENDPATH**/ ?>