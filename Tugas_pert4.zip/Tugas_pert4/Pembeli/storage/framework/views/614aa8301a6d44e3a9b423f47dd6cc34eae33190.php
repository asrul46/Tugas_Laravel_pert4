<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">List Sepeda Motor</div>
                <div> <a href="<?php echo e(route('motors.create')); ?>" class="btn btn-danger">ADD LIST </a></div>

                <div class="card-body">
                        <table class="table table-striped">
                        <tr>
                            <th>No</th>
                            <th>Nama</th>
                            <th>Merk</th>
                            <th>Isi silinder</th>
                            <th>Tahun</th>
                            <th>Harga</th>
                            <th>Aksi</th>

                        </tr>
                        <?php  $no=1; ?>
                        <?php $__currentLoopData = $motors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($no); ?></td>
                            <td><?php echo e($item->nama); ?></td>
                            <td><?php echo e($item->merk); ?></td>
                            <td><?php echo e($item->isi_silinder); ?></td>
                            <td><?php echo e($item->tahun_buat); ?></td>
                            <td><?php echo e($item->harga); ?></td> 
                            <td>
                                <a href="<?php echo e(route('motors.edit',$item->id)); ?>" class="btn btn-info btn-sm">EDIT </a>
                                <form method="POST" action="<?php echo e(route('motors.destroy',$item->id)); ?>">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                
                                <button type="submit" class="btn btn-danger btn-sm">DELETE </button>
                                </form>

                            </td>
                        </tr>
                        <?php $no++; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                      
                        </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\motor\resources\views/motors/index.blade.php ENDPATH**/ ?>