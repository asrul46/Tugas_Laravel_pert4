<?php

use Illuminate\Database\Seeder;

class PembeliTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $pembeli=[
            [
                'no_transaksi'=>'0001',
                'nama_pembeli'=>'Asrul',
                'merk'=>'Rosebrand',
                'jumlah_barang'=>'100',
                'harga'=>'500000',

            ],
            [
                'no_transaksi'=>'0002',
                'nama_pembeli'=>'Ilhak',
                'merk'=>'Aqua',
                'jumlah_barang'=>'50',
                'harga'=>'50000',

            ],
            [
                'no_transaksi'=>'0003',
                'nama_pembeli'=>'Ryo',
                'merk'=>'Signature',
                'jumlah_barang'=>'100',
                'harga'=>'90000',

            ],
        ];
        DB::table('pembeli')->insert($pembeli);
    }
}
